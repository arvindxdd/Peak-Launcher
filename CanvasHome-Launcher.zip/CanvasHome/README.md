# CanvasHome — Freeform Canvas Android Launcher

An open-source Android Home Launcher inspired by Samsung Good Lock Home Up DIY — built for **any** Android phone (including Vivo Funtouch OS / OriginOS). Place **widgets, app icons, and text stickers anywhere on your screen** with zero grid constraints, free resizing, 360° rotation, layering, and opacity control.

## Features
- **Zero-Grid Canvas:** Drag any widget, app icon, or text sticker to exact pixel coordinates.
- **Free Sizing + Scaling:** Drag the bottom-right corner handle to resize widget bounds live (`updateAppWidgetSize`), OR pinch/slide to visually scale (`35%–250%`) past stubborn OEM widget minimums.
- **360° Free Rotation:** Drag the amber top rotation handle, two-finger twist, or use the exact degree slider (`-180°` to `+180°`).
- **Smart Center Snap Guides (Toggleable):** Instant center-X / center-Y crosshairs and 0°/90° angle snaps — or toggle `Snap: OFF` for pure freehand placement.
- **1-Pixel Micro-Nudge D-Pad:** Dial a clock widget dead-center onto a wallpaper element in seconds.
- **Z-Index Layering & Opacity:** Stack items over/under each other (`Front` / `Back`) and adjust transparency (`15%–100%`).
- **App Icon Styling:** Hide/show labels and apply Circle, Rounded Square, or Original icon masks per icon.
- **Text / Quote Stickers:** Drop custom text or translucent glassmorphic notes anywhere on your home screen.
- **Swipe-Up App Drawer + Searchable Widget Picker**
- **Native System Wallpaper Passthrough:** Uses your real phone wallpaper edge-to-edge at native aspect ratio.
- **Clipboard JSON Layout Backup & Restore**

## Easiest Way to Get the APK (GitHub Actions — Zero Local Setup!)
1. Create a new repository on [GitHub](https://github.com/new) (public or private).
2. Extract this ZIP and push all files to your repository's `main` branch (or upload the files directly in GitHub).
3. Open the **Actions** tab in your GitHub repo.
4. Open the **Build CanvasHome APK** run (triggers automatically on push).
5. When it turns green (~2 minutes), scroll to **Artifacts**, download **`CanvasHome-APK`**, unzip it, and install `app-debug.apk` on your phone.

## Build Locally (Android Studio)
1. Open the extracted `CanvasHome` folder in Android Studio (JDK 17).
2. Let Gradle sync, then go to **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Setting as Default Launcher on Vivo (Funtouch OS / OriginOS)
1. Install `app-debug.apk`.
2. Go to **Settings → Apps → Default apps → Home app** and select **CanvasHome**.
   *(If Vivo prompts for permission to change the system launcher, enable **Allow third-party launcher** in Settings → Security / Home screen settings, or open CanvasHome once and tap `••• → Set as Default Home Launcher`.)*
3. **Long-press anywhere on the wallpaper** to enter Edit Mode, or **swipe up** from the bottom for your App Drawer.
