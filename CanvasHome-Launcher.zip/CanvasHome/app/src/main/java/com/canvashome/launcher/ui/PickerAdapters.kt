package com.canvashome.launcher.ui

import android.appwidget.AppWidgetProviderInfo
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.canvashome.launcher.R

data class InstalledAppEntry(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: Drawable
)

data class WidgetPickerEntry(
    val providerInfo: AppWidgetProviderInfo,
    val widgetLabel: String,
    val appLabel: String,
    val preview: Drawable?
)

class AppDrawerAdapter(
    private val onTap: (InstalledAppEntry) -> Unit,
    private val onLongPress: (InstalledAppEntry) -> Unit
) : RecyclerView.Adapter<AppDrawerAdapter.VH>() {

    private val items = mutableListOf<InstalledAppEntry>()

    fun submit(list: List<InstalledAppEntry>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val ivIcon: ImageView = view.findViewById(R.id.ivAppIcon)
        val tvLabel: TextView = view.findViewById(R.id.tvAppLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app_drawer, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val entry = items[position]
        holder.ivIcon.setImageDrawable(entry.icon)
        holder.tvLabel.text = entry.label
        holder.itemView.setOnClickListener { onTap(entry) }
        holder.itemView.setOnLongClickListener {
            onLongPress(entry)
            true
        }
    }

    override fun getItemCount(): Int = items.size
}

class WidgetPickerAdapter(
    private val onPick: (WidgetPickerEntry) -> Unit
) : RecyclerView.Adapter<WidgetPickerAdapter.VH>() {

    private val items = mutableListOf<WidgetPickerEntry>()

    fun submit(list: List<WidgetPickerEntry>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val ivPreview: ImageView = view.findViewById(R.id.ivWidgetPreview)
        val tvName: TextView = view.findViewById(R.id.tvWidgetName)
        val tvApp: TextView = view.findViewById(R.id.tvWidgetApp)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_widget_picker, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val entry = items[position]
        holder.ivPreview.setImageDrawable(entry.preview)
        holder.tvName.text = entry.widgetLabel
        holder.tvApp.text = entry.appLabel
        holder.itemView.setOnClickListener { onPick(entry) }
    }

    override fun getItemCount(): Int = items.size
}
