package com.canvashome.launcher.data

import android.content.Context
import com.canvashome.launcher.model.CanvasItem
import org.json.JSONArray

class CanvasStorage(context: Context) {

    private val prefs = context.getSharedPreferences("canvashome_prefs", Context.MODE_PRIVATE)

    fun saveItems(items: List<CanvasItem>) {
        val arr = JSONArray()
        items.sortedBy { it.zIndex }.forEach { arr.put(it.toJson()) }
        prefs.edit().putString(KEY_ITEMS, arr.toString()).apply()
    }

    fun loadItems(): MutableList<CanvasItem> {
        val raw = prefs.getString(KEY_ITEMS, null) ?: return mutableListOf()
        return parseJson(raw)
    }

    fun exportJson(items: List<CanvasItem>): String {
        val arr = JSONArray()
        items.sortedBy { it.zIndex }.forEach { arr.put(it.toJson()) }
        return arr.toString(2)
    }

    fun parseJson(raw: String): MutableList<CanvasItem> {
        val result = mutableListOf<CanvasItem>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                result.add(CanvasItem.fromJson(arr.getJSONObject(i)))
            }
        }
        return result
    }

    fun isSnapEnabled(): Boolean = prefs.getBoolean(KEY_SNAP, true)

    fun setSnapEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SNAP, enabled).apply()
    }

    companion object {
        private const val KEY_ITEMS = "canvas_items_v1"
        private const val KEY_SNAP = "snap_guides_enabled"
    }
}
