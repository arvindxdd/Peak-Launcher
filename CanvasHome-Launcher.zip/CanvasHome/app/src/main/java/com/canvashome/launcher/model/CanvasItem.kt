package com.canvashome.launcher.model

import org.json.JSONObject
import java.util.UUID

enum class CanvasItemType {
    WIDGET,
    APP,
    TEXT_STICKER
}

enum class IconShape {
    ORIGINAL,
    CIRCLE,
    ROUNDED_SQUARE
}

data class CanvasItem(
    val id: String = UUID.randomUUID().toString(),
    val type: CanvasItemType,
    var x: Float,
    var y: Float,
    var widthPx: Int,
    var heightPx: Int,
    var rotation: Float = 0f,
    var scale: Float = 1f,
    var alpha: Float = 1f,
    var zIndex: Int = 0,
    var appWidgetId: Int = -1,
    var widgetLabel: String = "",
    var packageName: String = "",
    var activityName: String = "",
    var appLabel: String = "",
    var showLabel: Boolean = true,
    var iconShape: IconShape = IconShape.ORIGINAL,
    var stickerText: String = "",
    var textSizeSp: Float = 18f,
    var textColor: Int = 0xFFF5F7FA.toInt(),
    var hasGlassBg: Boolean = true
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("type", type.name)
        put("x", x.toDouble())
        put("y", y.toDouble())
        put("widthPx", widthPx)
        put("heightPx", heightPx)
        put("rotation", rotation.toDouble())
        put("scale", scale.toDouble())
        put("alpha", alpha.toDouble())
        put("zIndex", zIndex)
        put("appWidgetId", appWidgetId)
        put("widgetLabel", widgetLabel)
        put("packageName", packageName)
        put("activityName", activityName)
        put("appLabel", appLabel)
        put("showLabel", showLabel)
        put("iconShape", iconShape.name)
        put("stickerText", stickerText)
        put("textSizeSp", textSizeSp.toDouble())
        put("textColor", textColor)
        put("hasGlassBg", hasGlassBg)
    }

    companion object {
        fun fromJson(obj: JSONObject): CanvasItem {
            val typeStr = obj.optString("type", CanvasItemType.APP.name)
            val type = runCatching { CanvasItemType.valueOf(typeStr) }.getOrDefault(CanvasItemType.APP)
            val shapeStr = obj.optString("iconShape", IconShape.ORIGINAL.name)
            val shape = runCatching { IconShape.valueOf(shapeStr) }.getOrDefault(IconShape.ORIGINAL)
            return CanvasItem(
                id = obj.optString("id", UUID.randomUUID().toString()),
                type = type,
                x = obj.optDouble("x", 100.0).toFloat(),
                y = obj.optDouble("y", 200.0).toFloat(),
                widthPx = obj.optInt("widthPx", 240).coerceAtLeast(48),
                heightPx = obj.optInt("heightPx", 240).coerceAtLeast(48),
                rotation = obj.optDouble("rotation", 0.0).toFloat(),
                scale = obj.optDouble("scale", 1.0).toFloat().coerceIn(0.35f, 2.5f),
                alpha = obj.optDouble("alpha", 1.0).toFloat().coerceIn(0.15f, 1.0f),
                zIndex = obj.optInt("zIndex", 0),
                appWidgetId = obj.optInt("appWidgetId", -1),
                widgetLabel = obj.optString("widgetLabel", ""),
                packageName = obj.optString("packageName", ""),
                activityName = obj.optString("activityName", ""),
                appLabel = obj.optString("appLabel", ""),
                showLabel = obj.optBoolean("showLabel", true),
                iconShape = shape,
                stickerText = obj.optString("stickerText", ""),
                textSizeSp = obj.optDouble("textSizeSp", 18.0).toFloat(),
                textColor = obj.optInt("textColor", 0xFFF5F7FA.toInt()),
                hasGlassBg = obj.optBoolean("hasGlassBg", true)
            )
        }
    }
}
