package com.canvashome.launcher

import android.annotation.SuppressLint
import android.app.Activity
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.SizeF
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.inputmethod.InputMethodManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.canvashome.launcher.data.CanvasStorage
import com.canvashome.launcher.model.CanvasItem
import com.canvashome.launcher.model.CanvasItemType
import com.canvashome.launcher.model.IconShape
import com.canvashome.launcher.ui.AppDrawerAdapter
import com.canvashome.launcher.ui.CanvasItemContainer
import com.canvashome.launcher.ui.InstalledAppEntry
import com.canvashome.launcher.ui.WidgetPickerAdapter
import com.canvashome.launcher.ui.WidgetPickerEntry
import com.canvashome.launcher.widget.FreeformWidgetHost
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity(), CanvasItemContainer.Callbacks {

    companion object {
        private const val APPWIDGET_HOST_ID = 20261122
        private const val REQUEST_CONFIGURE_WIDGET = 9002
    }

    private lateinit var storage: CanvasStorage
    private lateinit var appWidgetManager: AppWidgetManager
    private lateinit var appWidgetHost: FreeformWidgetHost

    private lateinit var canvasLayer: FrameLayout
    private lateinit var guideVertical: View
    private lateinit var guideHorizontal: View
    private lateinit var hudBadge: TextView
    private lateinit var emptyStateCard: LinearLayout
    private lateinit var editTopBar: LinearLayout
    private lateinit var inspectorPanel: LinearLayout
    private lateinit var drawerTriggerZone: LinearLayout
    private lateinit var appDrawerOverlay: LinearLayout
    private lateinit var widgetPickerOverlay: LinearLayout

    private lateinit var btnToggleSnap: TextView

    private lateinit var inspectorTitle: TextView
    private lateinit var btnExtraAction: TextView
    private lateinit var lblRotation: TextView
    private lateinit var lblScale: TextView
    private lateinit var lblOpacity: TextView
    private lateinit var seekRotation: SeekBar
    private lateinit var seekScale: SeekBar
    private lateinit var seekOpacity: SeekBar

    private lateinit var etSearchApps: EditText
    private lateinit var tvDrawerModeHint: TextView
    private lateinit var rvAppDrawer: RecyclerView
    private lateinit var etSearchWidgets: EditText
    private lateinit var rvWidgetPicker: RecyclerView

    private lateinit var appDrawerAdapter: AppDrawerAdapter
    private lateinit var widgetPickerAdapter: WidgetPickerAdapter

    private val allApps = mutableListOf<InstalledAppEntry>()
    private val allWidgets = mutableListOf<WidgetPickerEntry>()

    private val canvasItems = mutableListOf<CanvasItem>()
    private val containerMap = mutableMapOf<String, CanvasItemContainer>()

    private var editMode = false
    private var snapEnabled = true
    private var drawerPickToAddMode = false
    private var selectedContainer: CanvasItemContainer? = null
    private var suppressSeekCallbacks = false

    private var pendingWidgetId: Int = -1
    private var pendingProviderInfo: AppWidgetProviderInfo? = null

    private val bindWidgetLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val widgetId = pendingWidgetId
        val info = pendingProviderInfo
        if (result.resultCode == Activity.RESULT_OK && widgetId != -1 && info != null) {
            finalizeWidgetPlacement(widgetId, info)
        } else {
            if (widgetId != -1) {
                appWidgetHost.deleteAppWidgetId(widgetId)
            }
            pendingWidgetId = -1
            pendingProviderInfo = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        storage = CanvasStorage(this)
        snapEnabled = storage.isSnapEnabled()
        appWidgetManager = AppWidgetManager.getInstance(this)
        appWidgetHost = FreeformWidgetHost(this, APPWIDGET_HOST_ID)

        bindViews()
        setupCanvasGestures()
        setupTopBarActions()
        setupInspectorControls()
        setupDrawerAndPickers()
        setupBackBehavior()

        loadInstalledApps()
        restoreSavedCanvas()
    }

    override fun onStart() {
        super.onStart()
        runCatching { appWidgetHost.startListening() }
    }

    override fun onStop() {
        super.onStop()
        runCatching { appWidgetHost.stopListening() }
    }

    private fun bindViews() {
        canvasLayer = findViewById(R.id.canvasLayer)
        guideVertical = findViewById(R.id.guideVertical)
        guideHorizontal = findViewById(R.id.guideHorizontal)
        hudBadge = findViewById(R.id.hudBadge)
        emptyStateCard = findViewById(R.id.emptyStateCard)
        editTopBar = findViewById(R.id.editTopBar)
        inspectorPanel = findViewById(R.id.inspectorPanel)
        drawerTriggerZone = findViewById(R.id.drawerTriggerZone)
        appDrawerOverlay = findViewById(R.id.appDrawerOverlay)
        widgetPickerOverlay = findViewById(R.id.widgetPickerOverlay)

        btnToggleSnap = findViewById(R.id.btnToggleSnap)

        inspectorTitle = findViewById(R.id.inspectorTitle)
        btnExtraAction = findViewById(R.id.btnExtraAction)
        lblRotation = findViewById(R.id.lblRotation)
        lblScale = findViewById(R.id.lblScale)
        lblOpacity = findViewById(R.id.lblOpacity)
        seekRotation = findViewById(R.id.seekRotation)
        seekScale = findViewById(R.id.seekScale)
        seekOpacity = findViewById(R.id.seekOpacity)

        etSearchApps = findViewById(R.id.etSearchApps)
        tvDrawerModeHint = findViewById(R.id.tvDrawerModeHint)
        rvAppDrawer = findViewById(R.id.rvAppDrawer)
        etSearchWidgets = findViewById(R.id.etSearchWidgets)
        rvWidgetPicker = findViewById(R.id.rvWidgetPicker)

        findViewById<View>(R.id.btnQuickStartEdit).setOnClickListener {
            setEditMode(true)
        }
        updateSnapButtonUi()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupCanvasGestures() {
        val gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (editMode) {
                    clearSelection()
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (!editMode) {
                    setEditMode(true)
                }
            }

            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                if (editMode || e1 == null) return false
                val dy = e1.y - e2.y
                val dx = abs(e1.x - e2.x)
                if (dy > dp(60) && abs(velocityY) > 350f && dy > dx) {
                    openAppDrawer(pickToAdd = false)
                    return true
                }
                return false
            }
        })

        canvasLayer.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
        }

        drawerTriggerZone.setOnClickListener {
            if (!editMode) openAppDrawer(pickToAdd = false)
        }
    }

    private fun setupTopBarActions() {
        findViewById<View>(R.id.btnAddWidget).setOnClickListener {
            openWidgetPicker()
        }
        findViewById<View>(R.id.btnAddApp).setOnClickListener {
            openAppDrawer(pickToAdd = true)
        }
        findViewById<View>(R.id.btnAddSticker).setOnClickListener {
            showTextStickerDialog(existingItem = null)
        }
        btnToggleSnap.setOnClickListener {
            snapEnabled = !snapEnabled
            storage.setSnapEnabled(snapEnabled)
            updateSnapButtonUi()
        }
        findViewById<View>(R.id.btnMoreMenu).setOnClickListener {
            showCanvasOptionsMenu()
        }
        findViewById<View>(R.id.btnDoneEdit).setOnClickListener {
            setEditMode(false)
        }
    }

    private fun updateSnapButtonUi() {
        btnToggleSnap.text = if (snapEnabled) "Snap: ON" else "Snap: OFF"
        btnToggleSnap.setTextColor(
            if (snapEnabled) Color.parseColor("#8AB4F8") else Color.parseColor("#A6B0C3")
        )
    }

    private fun setupInspectorControls() {
        findViewById<View>(R.id.btnDeleteItem).setOnClickListener {
            selectedContainer?.let { deleteItem(it) }
        }
        findViewById<View>(R.id.btnLayerUp).setOnClickListener {
            selectedContainer?.let { container ->
                val maxZ = (canvasItems.maxOfOrNull { it.zIndex } ?: 0) + 1
                container.item.zIndex = maxZ
                container.elevation = maxZ.toFloat()
                container.bringToFront()
                saveCanvas()
                toast("Moved to front")
            }
        }
        findViewById<View>(R.id.btnLayerDown).setOnClickListener {
            selectedContainer?.let { container ->
                val minZ = (canvasItems.minOfOrNull { it.zIndex } ?: 0) - 1
                container.item.zIndex = minZ
                container.elevation = minZ.toFloat()
                canvasLayer.removeView(container)
                canvasLayer.addView(container, 0)
                saveCanvas()
                toast("Sent to back")
            }
        }

        btnExtraAction.setOnClickListener {
            val container = selectedContainer ?: return@setOnClickListener
            when (container.item.type) {
                CanvasItemType.APP -> showAppStyleDialog(container)
                CanvasItemType.TEXT_STICKER -> showTextStickerDialog(container)
                CanvasItemType.WIDGET -> {
                    container.item.scale = 1f
                    container.applyModelToView()
                    updateWidgetOptions(container)
                    syncInspectorFrom(container)
                    saveCanvas()
                }
            }
        }

        val nudgeStep = dp(2).toFloat()
        findViewById<View>(R.id.btnNudgeLeft).setOnClickListener { nudgeSelected(-nudgeStep, 0f) }
        findViewById<View>(R.id.btnNudgeRight).setOnClickListener { nudgeSelected(nudgeStep, 0f) }
        findViewById<View>(R.id.btnNudgeUp).setOnClickListener { nudgeSelected(0f, -nudgeStep) }
        findViewById<View>(R.id.btnNudgeDown).setOnClickListener { nudgeSelected(0f, nudgeStep) }

        findViewById<View>(R.id.btnCenterX).setOnClickListener {
            selectedContainer?.let { container ->
                container.item.x = (canvasLayer.width - container.item.widthPx) / 2f
                container.applyModelToView()
                saveCanvas()
            }
        }
        findViewById<View>(R.id.btnResetRotate).setOnClickListener {
            selectedContainer?.let { container ->
                container.item.rotation = 0f
                container.applyModelToView()
                syncInspectorFrom(container)
                saveCanvas()
            }
        }

        seekRotation.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (suppressSeekCallbacks || !fromUser) return
                val container = selectedContainer ?: return
                val deg = (progress - 180).toFloat()
                container.item.rotation = deg
                container.rotation = deg
                lblRotation.text = "Rot: ${deg.roundToInt()}°"
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                saveCanvas()
            }
        })

        seekScale.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (suppressSeekCallbacks || !fromUser) return
                val container = selectedContainer ?: return
                val scale = (35 + progress) / 100f
                container.item.scale = scale
                container.scaleX = scale
                container.scaleY = scale
                lblScale.text = "Scale: ${(scale * 100).roundToInt()}%"
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                saveCanvas()
            }
        })

        seekOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (suppressSeekCallbacks || !fromUser) return
                val container = selectedContainer ?: return
                val a = (15 + progress) / 100f
                container.item.alpha = a
                container.alpha = a
                lblOpacity.text = "Alpha: ${(a * 100).roundToInt()}%"
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                saveCanvas()
            }
        })
    }

    private fun nudgeSelected(dx: Float, dy: Float) {
        val container = selectedContainer ?: return
        container.item.x += dx
        container.item.y += dy
        container.applyModelToView()
        saveCanvas()
    }

    private fun setupDrawerAndPickers() {
        appDrawerAdapter = AppDrawerAdapter(
            onTap = { entry ->
                if (drawerPickToAddMode) {
                    closeOverlays()
                    addAppToCanvas(entry)
                } else {
                    closeOverlays()
                    launchApp(entry.packageName, entry.activityName)
                }
            },
            onLongPress = { entry ->
                closeOverlays()
                setEditMode(true)
                addAppToCanvas(entry)
            }
        )
        rvAppDrawer.layoutManager = GridLayoutManager(this, 4)
        rvAppDrawer.adapter = appDrawerAdapter

        findViewById<View>(R.id.btnCloseDrawer).setOnClickListener { closeOverlays() }
        etSearchApps.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = s?.toString()?.trim().orEmpty()
                val filtered = if (q.isEmpty()) allApps else allApps.filter {
                    it.label.contains(q, ignoreCase = true)
                }
                appDrawerAdapter.submit(filtered)
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        widgetPickerAdapter = WidgetPickerAdapter { entry ->
            closeOverlays()
            requestBindWidget(entry.providerInfo)
        }
        rvWidgetPicker.layoutManager = LinearLayoutManager(this)
        rvWidgetPicker.adapter = widgetPickerAdapter

        findViewById<View>(R.id.btnCloseWidgetPicker).setOnClickListener { closeOverlays() }
        etSearchWidgets.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = s?.toString()?.trim().orEmpty()
                val filtered = if (q.isEmpty()) allWidgets else allWidgets.filter {
                    it.widgetLabel.contains(q, ignoreCase = true) ||
                        it.appLabel.contains(q, ignoreCase = true)
                }
                widgetPickerAdapter.submit(filtered)
            }

            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun setupBackBehavior() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    appDrawerOverlay.visibility == View.VISIBLE || widgetPickerOverlay.visibility == View.VISIBLE -> {
                        closeOverlays()
                    }
                    editMode -> {
                        setEditMode(false)
                    }
                    else -> {
                        // Home screen stays put on back press
                    }
                }
            }
        })
    }

    private fun loadInstalledApps() {
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val pm = packageManager
        val resolves = pm.queryIntentActivities(intent, 0)
        allApps.clear()
        for (ri in resolves) {
            val pkg = ri.activityInfo.packageName
            if (pkg == packageName) continue
            allApps.add(
                InstalledAppEntry(
                    label = ri.loadLabel(pm).toString(),
                    packageName = pkg,
                    activityName = ri.activityInfo.name,
                    icon = ri.loadIcon(pm)
                )
            )
        }
        allApps.sortBy { it.label.lowercase() }
        appDrawerAdapter.submit(allApps)
    }

    private fun loadInstalledWidgets() {
        val pm = packageManager
        val providers = appWidgetManager.installedProviders
        allWidgets.clear()
        for (info in providers) {
            val appName = runCatching {
                val ai = pm.getApplicationInfo(info.provider.packageName, 0)
                pm.getApplicationLabel(ai).toString()
            }.getOrDefault(info.provider.packageName)

            val label = runCatching { info.loadLabel(pm) }.getOrNull().orEmpty().ifBlank { appName }
            val preview = runCatching {
                info.loadPreviewImage(this, resources.displayMetrics.densityDpi)
                    ?: info.loadIcon(this, resources.displayMetrics.densityDpi)
            }.getOrNull()

            allWidgets.add(
                WidgetPickerEntry(
                    providerInfo = info,
                    widgetLabel = label,
                    appLabel = appName,
                    preview = preview
                )
            )
        }
        allWidgets.sortWith(compareBy({ it.appLabel.lowercase() }, { it.widgetLabel.lowercase() }))
        widgetPickerAdapter.submit(allWidgets)
    }

    private fun openAppDrawer(pickToAdd: Boolean) {
        drawerPickToAddMode = pickToAdd
        etSearchApps.setText("")
        loadInstalledApps()
        tvDrawerModeHint.text = if (pickToAdd) {
            "Tap any app to place it freely on your canvas"
        } else {
            "Tap to launch • Long-press any app to place it on your canvas"
        }
        widgetPickerOverlay.visibility = View.GONE
        appDrawerOverlay.visibility = View.VISIBLE
    }

    private fun openWidgetPicker() {
        etSearchWidgets.setText("")
        loadInstalledWidgets()
        appDrawerOverlay.visibility = View.GONE
        widgetPickerOverlay.visibility = View.VISIBLE
    }

    private fun closeOverlays() {
        appDrawerOverlay.visibility = View.GONE
        widgetPickerOverlay.visibility = View.GONE
        hideKeyboard()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        currentFocus?.let { imm?.hideSoftInputFromWindow(it.windowToken, 0) }
    }

    private fun setEditMode(enabled: Boolean) {
        editMode = enabled
        editTopBar.visibility = if (enabled) View.VISIBLE else View.GONE
        drawerTriggerZone.visibility = if (enabled) View.GONE else View.VISIBLE
        if (!enabled) {
            clearSelection()
            hudBadge.visibility = View.GONE
            guideVertical.visibility = View.GONE
            guideHorizontal.visibility = View.GONE
            saveCanvas()
        }
        updateEmptyState()
    }

    private fun clearSelection() {
        selectedContainer?.setSelectedEdit(false)
        selectedContainer = null
        inspectorPanel.visibility = View.GONE
    }

    private fun syncInspectorFrom(container: CanvasItemContainer) {
        val item = container.item
        inspectorPanel.visibility = View.VISIBLE
        inspectorTitle.text = when (item.type) {
            CanvasItemType.WIDGET -> item.widgetLabel.ifBlank { "Widget" }
            CanvasItemType.APP -> item.appLabel.ifBlank { "App Icon" }
            CanvasItemType.TEXT_STICKER -> "Sticker: ${item.stickerText.take(18)}"
        }
        btnExtraAction.visibility = View.VISIBLE
        btnExtraAction.text = when (item.type) {
            CanvasItemType.APP -> "Style"
            CanvasItemType.TEXT_STICKER -> "Edit Text"
            CanvasItemType.WIDGET -> "Reset 1x"
        }

        suppressSeekCallbacks = true
        seekRotation.progress = (item.rotation.roundToInt() + 180).coerceIn(0, 360)
        lblRotation.text = "Rot: ${item.rotation.roundToInt()}°"

        seekScale.progress = ((item.scale * 100).roundToInt() - 35).coerceIn(0, 185)
        lblScale.text = "Scale: ${(item.scale * 100).roundToInt()}%"

        seekOpacity.progress = ((item.alpha * 100).roundToInt() - 15).coerceIn(0, 85)
        lblOpacity.text = "Alpha: ${(item.alpha * 100).roundToInt()}%"
        suppressSeekCallbacks = false
    }

    private fun requestBindWidget(info: AppWidgetProviderInfo) {
        val widgetId = appWidgetHost.allocateAppWidgetId()
        pendingWidgetId = widgetId
        pendingProviderInfo = info

        val allowed = appWidgetManager.bindAppWidgetIdIfAllowed(widgetId, info.provider)
        if (allowed) {
            finalizeWidgetPlacement(widgetId, info)
        } else {
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER_PROFILE, info.profile)
            }
            bindWidgetLauncher.launch(intent)
        }
    }

    private fun finalizeWidgetPlacement(widgetId: Int, info: AppWidgetProviderInfo) {
        val isOptional = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            (info.widgetFeatures and AppWidgetProviderInfo.WIDGET_FEATURE_CONFIGURATION_OPTIONAL) != 0
        } else {
            false
        }
        val needsConfig = info.configure != null && !isOptional

        if (needsConfig) {
            runCatching {
                appWidgetHost.startAppWidgetConfigureActivityForResult(
                    this,
                    widgetId,
                    0,
                    REQUEST_CONFIGURE_WIDGET,
                    null
                )
            }.onFailure {
                addBoundWidgetToCanvas(widgetId, info)
            }
        } else {
            addBoundWidgetToCanvas(widgetId, info)
        }
    }

    @Deprecated("Required for AppWidgetHost.startAppWidgetConfigureActivityForResult")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CONFIGURE_WIDGET) {
            val widgetId = pendingWidgetId
            val info = pendingProviderInfo
            if (resultCode == Activity.RESULT_OK && widgetId != -1 && info != null) {
                addBoundWidgetToCanvas(widgetId, info)
            } else if (widgetId != -1) {
                appWidgetHost.deleteAppWidgetId(widgetId)
            }
            pendingWidgetId = -1
            pendingProviderInfo = null
        }
    }

    private fun addBoundWidgetToCanvas(widgetId: Int, info: AppWidgetProviderInfo) {
        val defaultW = info.minWidth.coerceIn(dp(110), dp(300))
        val defaultH = info.minHeight.coerceIn(dp(110), dp(300))
        val startX = ((canvasLayer.width - defaultW) / 2f).coerceAtLeast(dp(16).toFloat())
        val startY = ((canvasLayer.height - defaultH) / 2.5f).coerceAtLeast(dp(80).toFloat())

        val item = CanvasItem(
            type = CanvasItemType.WIDGET,
            x = startX,
            y = startY,
            widthPx = defaultW,
            heightPx = defaultH,
            zIndex = nextZIndex(),
            appWidgetId = widgetId,
            widgetLabel = runCatching { info.loadLabel(packageManager) }.getOrNull().orEmpty().ifBlank { "Widget" }
        )
        canvasItems.add(item)
        val container = attachItemView(item)
        saveCanvas()
        updateEmptyState()
        if (container != null) {
            setEditMode(true)
            onSelect(container)
        }
    }

    private fun addAppToCanvas(entry: InstalledAppEntry) {
        val sizePx = dp(82)
        val startX = ((canvasLayer.width - sizePx) / 2f).coerceAtLeast(dp(24).toFloat())
        val startY = ((canvasLayer.height - sizePx) / 2f).coerceAtLeast(dp(120).toFloat())

        val item = CanvasItem(
            type = CanvasItemType.APP,
            x = startX,
            y = startY,
            widthPx = sizePx,
            heightPx = dp(94),
            zIndex = nextZIndex(),
            packageName = entry.packageName,
            activityName = entry.activityName,
            appLabel = entry.label
        )
        canvasItems.add(item)
        val container = attachItemView(item)
        saveCanvas()
        updateEmptyState()
        if (container != null && editMode) {
            onSelect(container)
        }
    }

    private fun showTextStickerDialog(existingItem: CanvasItemContainer?) {
        val containerView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(4))
        }
        val input = EditText(this).apply {
            hint = "Write quote, label, or note…"
            setText(existingItem?.item?.stickerText.orEmpty())
        }
        val glassToggle = CheckBox(this).apply {
            text = "Frosted dark pill background"
            isChecked = existingItem?.item?.hasGlassBg ?: true
        }
        containerView.addView(input)
        containerView.addView(glassToggle)

        AlertDialog.Builder(this)
            .setTitle(if (existingItem == null) "Add Canvas Text Sticker" else "Edit Text Sticker")
            .setView(containerView)
            .setPositiveButton("Save") { _, _ ->
                val text = input.text.toString().trim()
                if (text.isEmpty()) return@setPositiveButton
                if (existingItem == null) {
                    val w = dp(200)
                    val h = dp(64)
                    val item = CanvasItem(
                        type = CanvasItemType.TEXT_STICKER,
                        x = ((canvasLayer.width - w) / 2f).coerceAtLeast(dp(20).toFloat()),
                        y = ((canvasLayer.height - h) / 3f).coerceAtLeast(dp(100).toFloat()),
                        widthPx = w,
                        heightPx = h,
                        zIndex = nextZIndex(),
                        stickerText = text,
                        hasGlassBg = glassToggle.isChecked
                    )
                    canvasItems.add(item)
                    val container = attachItemView(item)
                    saveCanvas()
                    updateEmptyState()
                    if (container != null) onSelect(container)
                } else {
                    existingItem.item.stickerText = text
                    existingItem.item.hasGlassBg = glassToggle.isChecked
                    rebuildItemContent(existingItem)
                    syncInspectorFrom(existingItem)
                    saveCanvas()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAppStyleDialog(container: CanvasItemContainer) {
        val item = container.item
        val options = arrayOf(
            if (item.showLabel) "Hide App Label" else "Show App Label",
            "Icon Mask: Original",
            "Icon Mask: Circle",
            "Icon Mask: Rounded Square"
        )
        AlertDialog.Builder(this)
            .setTitle("${item.appLabel} Style")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> item.showLabel = !item.showLabel
                    1 -> item.iconShape = IconShape.ORIGINAL
                    2 -> item.iconShape = IconShape.CIRCLE
                    3 -> item.iconShape = IconShape.ROUNDED_SQUARE
                }
                rebuildItemContent(container)
                saveCanvas()
            }
            .show()
    }

    private fun showCanvasOptionsMenu() {
        val options = arrayOf(
            "Set as Default Home Launcher",
            "Change Wallpaper",
            "Copy Layout JSON (Backup)",
            "Restore Layout from Clipboard",
            "Clear All Canvas Items"
        )
        AlertDialog.Builder(this)
            .setTitle("CanvasHome Studio")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> runCatching {
                        startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                    }.onFailure { toast("Open Settings → Default Apps → Home App") }

                    1 -> runCatching {
                        startActivity(Intent(Intent.ACTION_SET_WALLPAPER))
                    }

                    2 -> {
                        val json = storage.exportJson(canvasItems)
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("CanvasHome Layout", json))
                        toast("Layout JSON copied to clipboard")
                    }

                    3 -> {
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val raw = cm.primaryClip?.getItemAt(0)?.text?.toString()
                        if (raw.isNullOrBlank()) {
                            toast("Clipboard is empty")
                        } else {
                            val parsed = storage.parseJson(raw)
                            if (parsed.isEmpty()) {
                                toast("No valid CanvasHome layout in clipboard")
                            } else {
                                clearAllItems(deleteWidgets = false)
                                canvasItems.addAll(parsed)
                                canvasItems.sortedBy { it.zIndex }.forEach { attachItemView(it) }
                                saveCanvas()
                                updateEmptyState()
                                toast("Layout restored")
                            }
                        }
                    }

                    4 -> {
                        AlertDialog.Builder(this)
                            .setTitle("Clear Canvas?")
                            .setMessage("Remove all widgets, apps, and stickers from your canvas?")
                            .setPositiveButton("Clear") { _, _ ->
                                clearAllItems(deleteWidgets = true)
                                saveCanvas()
                                updateEmptyState()
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                    }
                }
            }
            .show()
    }

    private fun restoreSavedCanvas() {
        canvasItems.clear()
        canvasItems.addAll(storage.loadItems())
        canvasItems.sortedBy { it.zIndex }.forEach { attachItemView(it) }
        updateEmptyState()
    }

    private fun attachItemView(item: CanvasItem): CanvasItemContainer? {
        val content = buildItemContentView(item) ?: return null
        val container = CanvasItemContainer(this, item, this)
        container.setContentView(content)
        canvasLayer.addView(container)
        containerMap[item.id] = container
        if (item.type == CanvasItemType.WIDGET) {
            updateWidgetOptions(container)
        }
        return container
    }

    private fun rebuildItemContent(container: CanvasItemContainer) {
        val content = buildItemContentView(container.item) ?: return
        container.setContentView(content)
    }

    private fun buildItemContentView(item: CanvasItem): View? {
        return when (item.type) {
            CanvasItemType.WIDGET -> {
                val info = appWidgetManager.getAppWidgetInfo(item.appWidgetId) ?: return null
                val hostView = appWidgetHost.createView(applicationContext, item.appWidgetId, info)
                hostView.setAppWidget(item.appWidgetId, info)
                hostView
            }

            CanvasItemType.APP -> {
                val wrapper = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setOnClickListener {
                        if (!editMode) {
                            launchApp(item.packageName, item.activityName)
                        }
                    }
                }
                val iconDrawable = runCatching {
                    val cn = ComponentName(item.packageName, item.activityName)
                    packageManager.getActivityIcon(cn)
                }.getOrElse {
                    runCatching { packageManager.getApplicationIcon(item.packageName) }.getOrNull()
                }

                val iv = ImageView(this).apply {
                    setImageDrawable(iconDrawable)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    clipToOutline = item.iconShape != IconShape.ORIGINAL
                    outlineProvider = object : ViewOutlineProvider() {
                        override fun getOutline(view: View, outline: Outline) {
                            when (item.iconShape) {
                                IconShape.CIRCLE -> outline.setOval(0, 0, view.width, view.height)
                                IconShape.ROUNDED_SQUARE -> outline.setRoundRect(
                                    0,
                                    0,
                                    view.width,
                                    view.height,
                                    view.width * 0.24f
                                )
                                IconShape.ORIGINAL -> outline.setRect(0, 0, view.width, view.height)
                            }
                        }
                    }
                }
                val iconLp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    0,
                    1f
                ).apply {
                    setMargins(dp(4), dp(4), dp(4), dp(2))
                }
                wrapper.addView(iv, iconLp)

                if (item.showLabel) {
                    val tv = TextView(this).apply {
                        text = item.appLabel
                        setTextColor(Color.WHITE)
                        textSize = 11f
                        gravity = Gravity.CENTER
                        maxLines = 1
                        setShadowLayer(4f, 0f, 1f, Color.BLACK)
                    }
                    wrapper.addView(
                        tv,
                        LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                    )
                }
                wrapper
            }

            CanvasItemType.TEXT_STICKER -> {
                TextView(this).apply {
                    text = item.stickerText
                    setTextColor(item.textColor)
                    textSize = item.textSizeSp
                    gravity = Gravity.CENTER
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                    if (item.hasGlassBg) {
                        setBackgroundResource(R.drawable.bg_sticker_pill)
                    } else {
                        setBackgroundColor(Color.TRANSPARENT)
                        setShadowLayer(6f, 0f, 2f, Color.BLACK)
                    }
                }
            }
        }
    }

    private fun updateWidgetOptions(container: CanvasItemContainer) {
        val hostView = container.getContentView() as? AppWidgetHostView ?: return
        val wDp = (container.item.widthPx / resources.displayMetrics.density).coerceAtLeast(32f)
        val hDp = (container.item.heightPx / resources.displayMetrics.density).coerceAtLeast(32f)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            hostView.updateAppWidgetSize(Bundle(), listOf(SizeF(wDp, hDp)))
        } else {
            @Suppress("DEPRECATION")
            hostView.updateAppWidgetSize(null, wDp.toInt(), hDp.toInt(), wDp.toInt(), hDp.toInt())
        }
    }

    private fun deleteItem(container: CanvasItemContainer) {
        val item = container.item
        if (item.type == CanvasItemType.WIDGET && item.appWidgetId != -1) {
            appWidgetHost.deleteAppWidgetId(item.appWidgetId)
        }
        canvasLayer.removeView(container)
        containerMap.remove(item.id)
        canvasItems.removeAll { it.id == item.id }
        clearSelection()
        saveCanvas()
        updateEmptyState()
    }

    private fun clearAllItems(deleteWidgets: Boolean) {
        if (deleteWidgets) {
            canvasItems.filter { it.type == CanvasItemType.WIDGET && it.appWidgetId != -1 }.forEach {
                appWidgetHost.deleteAppWidgetId(it.appWidgetId)
            }
        }
        canvasLayer.removeAllViews()
        containerMap.clear()
        canvasItems.clear()
        clearSelection()
    }

    private fun launchApp(pkg: String, activity: String) {
        runCatching {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                component = ComponentName(pkg, activity)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
            }
            startActivity(intent)
        }.onFailure {
            val fallback = packageManager.getLaunchIntentForPackage(pkg)
            if (fallback != null) startActivity(fallback)
        }
    }

    private fun updateEmptyState() {
        emptyStateCard.visibility = if (canvasItems.isEmpty() && !editMode) View.VISIBLE else View.GONE
    }

    private fun saveCanvas() {
        storage.saveItems(canvasItems)
    }

    private fun nextZIndex(): Int = (canvasItems.maxOfOrNull { it.zIndex } ?: 0) + 1

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun isEditMode(): Boolean = editMode

    override fun isSnapEnabled(): Boolean = snapEnabled

    override fun onSelect(container: CanvasItemContainer) {
        if (selectedContainer != container) {
            selectedContainer?.setSelectedEdit(false)
            selectedContainer = container
            container.setSelectedEdit(true)
        }
        syncInspectorFrom(container)
    }

    override fun onTransformLive(container: CanvasItemContainer, hudText: String) {
        hudBadge.text = hudText
        hudBadge.visibility = View.VISIBLE
        if (selectedContainer == container) {
            syncInspectorFrom(container)
        }
    }

    override fun onSnapGuides(showVertical: Boolean, showHorizontal: Boolean) {
        guideVertical.visibility = if (showVertical) View.VISIBLE else View.GONE
        guideHorizontal.visibility = if (showHorizontal) View.VISIBLE else View.GONE
    }

    override fun onTransformEnd(container: CanvasItemContainer) {
        hudBadge.visibility = View.GONE
        saveCanvas()
    }

    override fun onResizeWidget(container: CanvasItemContainer) {
        if (container.item.type == CanvasItemType.WIDGET) {
            updateWidgetOptions(container)
        }
    }
}
