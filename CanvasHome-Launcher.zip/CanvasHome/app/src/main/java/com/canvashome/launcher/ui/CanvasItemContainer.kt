package com.canvashome.launcher.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.canvashome.launcher.R
import com.canvashome.launcher.model.CanvasItem
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin

class CanvasItemContainer(
    context: Context,
    val item: CanvasItem,
    private val callbacks: Callbacks
) : FrameLayout(context) {

    interface Callbacks {
        fun isEditMode(): Boolean
        fun isSnapEnabled(): Boolean
        fun onSelect(container: CanvasItemContainer)
        fun onTransformLive(container: CanvasItemContainer, hudText: String)
        fun onSnapGuides(showVertical: Boolean, showHorizontal: Boolean)
        fun onTransformEnd(container: CanvasItemContainer)
        fun onResizeWidget(container: CanvasItemContainer)
    }

    private val contentHolder = FrameLayout(context).apply {
        clipChildren = false
        clipToPadding = false
    }

    private val selectionBorder = View(context).apply {
        setBackgroundResource(R.drawable.bg_selection_border)
        visibility = View.GONE
    }

    private val resizeHandle = View(context).apply {
        setBackgroundResource(R.drawable.bg_handle_circle)
        visibility = View.GONE
    }

    private val rotateStem = View(context).apply {
        setBackgroundColor(Color.parseColor("#CCF6B26B"))
        visibility = View.GONE
    }

    private val rotateHandle = View(context).apply {
        setBackgroundResource(R.drawable.bg_handle_rotate)
        visibility = View.GONE
    }

    private var isSelectedState = false

    private var dragStartRawX = 0f
    private var dragStartRawY = 0f
    private var startItemX = 0f
    private var startItemY = 0f

    private var isMultiTouch = false
    private var initialPinchDist = 1f
    private var initialPinchAngle = 0f
    private var startScale = 1f
    private var startRotation = 0f

    private var handleStartRawX = 0f
    private var handleStartRawY = 0f
    private var handleStartWidth = 0
    private var handleStartHeight = 0

    private val handleSizePx = dp(26)
    private val rotateOffsetPx = dp(34)

    init {
        clipChildren = false
        clipToPadding = false

        addView(
            contentHolder,
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        )
        addView(
            selectionBorder,
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        )

        val resizeLp = LayoutParams(handleSizePx, handleSizePx, Gravity.BOTTOM or Gravity.END).apply {
            marginEnd = -handleSizePx / 3
            bottomMargin = -handleSizePx / 3
        }
        addView(resizeHandle, resizeLp)

        val stemLp = LayoutParams(dp(2), rotateOffsetPx, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = -rotateOffsetPx
        }
        addView(rotateStem, stemLp)

        val rotateLp = LayoutParams(handleSizePx, handleSizePx, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = -rotateOffsetPx - handleSizePx / 2
        }
        addView(rotateHandle, rotateLp)

        setupHandleTouchListeners()
        applyModelToView()
    }

    fun setContentView(child: View) {
        contentHolder.removeAllViews()
        contentHolder.addView(
            child,
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        )
    }

    fun getContentView(): View? = if (contentHolder.childCount > 0) contentHolder.getChildAt(0) else null

    fun applyModelToView() {
        layoutParams = (layoutParams as? LayoutParams ?: LayoutParams(item.widthPx, item.heightPx)).apply {
            width = item.widthPx
            height = item.heightPx
        }
        x = item.x
        y = item.y
        rotation = item.rotation
        scaleX = item.scale
        scaleY = item.scale
        alpha = item.alpha
        elevation = item.zIndex.toFloat()
        requestLayout()
    }

    fun setSelectedEdit(selected: Boolean) {
        isSelectedState = selected
        val vis = if (selected && callbacks.isEditMode()) View.VISIBLE else View.GONE
        selectionBorder.visibility = vis
        resizeHandle.visibility = vis
        rotateStem.visibility = vis
        rotateHandle.visibility = vis
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (!callbacks.isEditMode()) {
            return false
        }
        if (isSelectedState && (isPointInView(resizeHandle, ev.x, ev.y) || isPointInView(rotateHandle, ev.x, ev.y))) {
            return false
        }
        return true
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!callbacks.isEditMode()) return false

        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                callbacks.onSelect(this)
                isMultiTouch = false
                dragStartRawX = ev.rawX
                dragStartRawY = ev.rawY
                startItemX = item.x
                startItemY = item.y
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (ev.pointerCount >= 2) {
                    isMultiTouch = true
                    initialPinchDist = spacing(ev).coerceAtLeast(10f)
                    initialPinchAngle = angle(ev)
                    startScale = item.scale
                    startRotation = item.rotation
                }
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (isMultiTouch && ev.pointerCount >= 2) {
                    val newDist = spacing(ev)
                    val newAngle = angle(ev)
                    val newScale = (startScale * (newDist / initialPinchDist)).coerceIn(0.35f, 2.5f)
                    var newRot = normalizeAngle(startRotation + (newAngle - initialPinchAngle))
                    if (callbacks.isSnapEnabled()) {
                        newRot = snapAngle(newRot)
                    }
                    item.scale = newScale
                    item.rotation = newRot
                    scaleX = newScale
                    scaleY = newScale
                    rotation = newRot
                    callbacks.onTransformLive(
                        this,
                        "${newRot.roundToInt()}°  •  ${(newScale * 100).roundToInt()}%"
                    )
                } else if (!isMultiTouch) {
                    val dx = ev.rawX - dragStartRawX
                    val dy = ev.rawY - dragStartRawY
                    var nextX = startItemX + dx
                    var nextY = startItemY + dy

                    val parentView = parent as? ViewGroup
                    var snapV = false
                    var snapH = false
                    if (callbacks.isSnapEnabled() && parentView != null) {
                        val parentCenterX = parentView.width / 2f
                        val parentCenterY = parentView.height / 2f
                        val itemCenterX = nextX + item.widthPx / 2f
                        val itemCenterY = nextY + item.heightPx / 2f
                        val snapThreshold = dp(10).toFloat()

                        if (abs(itemCenterX - parentCenterX) <= snapThreshold) {
                            nextX = parentCenterX - item.widthPx / 2f
                            snapV = true
                        }
                        if (abs(itemCenterY - parentCenterY) <= snapThreshold) {
                            nextY = parentCenterY - item.heightPx / 2f
                            snapH = true
                        }
                    }

                    item.x = nextX
                    item.y = nextY
                    x = nextX
                    y = nextY
                    callbacks.onSnapGuides(snapV, snapH)
                    callbacks.onTransformLive(this, "X ${nextX.roundToInt()}  •  Y ${nextY.roundToInt()}")
                }
                return true
            }

            MotionEvent.ACTION_POINTER_UP -> {
                if (ev.pointerCount <= 2) {
                    isMultiTouch = false
                    dragStartRawX = ev.rawX
                    dragStartRawY = ev.rawY
                    startItemX = item.x
                    startItemY = item.y
                }
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isMultiTouch = false
                callbacks.onSnapGuides(false, false)
                callbacks.onTransformEnd(this)
                return true
            }
        }
        return super.onTouchEvent(ev)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupHandleTouchListeners() {
        resizeHandle.setOnTouchListener { _, ev ->
            if (!callbacks.isEditMode()) return@setOnTouchListener false
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    handleStartRawX = ev.rawX
                    handleStartRawY = ev.rawY
                    handleStartWidth = item.widthPx
                    handleStartHeight = item.heightPx
                    parent?.requestDisallowInterceptTouchEvent(true)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - handleStartRawX
                    val dy = ev.rawY - handleStartRawY
                    val rad = Math.toRadians(-item.rotation.toDouble())
                    val localDx = (dx * cos(rad) - dy * sin(rad)) / item.scale
                    val localDy = (dx * sin(rad) + dy * cos(rad)) / item.scale

                    val minDim = dp(44)
                    val newW = (handleStartWidth + localDx).roundToInt().coerceIn(minDim, dp(420))
                    val newH = (handleStartHeight + localDy).roundToInt().coerceIn(minDim, dp(640))

                    item.widthPx = newW
                    item.heightPx = newH
                    layoutParams.width = newW
                    layoutParams.height = newH
                    requestLayout()
                    callbacks.onTransformLive(this, "${pxToDp(newW)} × ${pxToDp(newH)} dp")
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    callbacks.onResizeWidget(this)
                    callbacks.onTransformEnd(this)
                    true
                }
                else -> false
            }
        }

        rotateHandle.setOnTouchListener { _, ev ->
            if (!callbacks.isEditMode()) return@setOnTouchListener false
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val parentView = parent as? View
                    val parentLoc = IntArray(2)
                    parentView?.getLocationOnScreen(parentLoc)
                    val centerX = parentLoc[0] + item.x + item.widthPx / 2f
                    val centerY = parentLoc[1] + item.y + item.heightPx / 2f
                    val angleRad = atan2((ev.rawY - centerY).toDouble(), (ev.rawX - centerX).toDouble())
                    var deg = normalizeAngle(Math.toDegrees(angleRad).toFloat() + 90f)
                    if (callbacks.isSnapEnabled()) {
                        deg = snapAngle(deg)
                    }
                    item.rotation = deg
                    rotation = deg
                    callbacks.onTransformLive(this, "Rotate ${deg.roundToInt()}°")
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    callbacks.onTransformEnd(this)
                    true
                }
                else -> false
            }
        }
    }

    private fun isPointInView(target: View, localX: Float, localY: Float): Boolean {
        if (target.visibility != View.VISIBLE) return false
        val slop = dp(14)
        return localX >= target.left - slop &&
            localX <= target.right + slop &&
            localY >= target.top - slop &&
            localY <= target.bottom + slop
    }

    private fun spacing(ev: MotionEvent): Float {
        val dx = ev.getX(0) - ev.getX(1)
        val dy = ev.getY(0) - ev.getY(1)
        return hypot(dx.toDouble(), dy.toDouble()).toFloat()
    }

    private fun angle(ev: MotionEvent): Float {
        val dx = (ev.getX(1) - ev.getX(0)).toDouble()
        val dy = (ev.getY(1) - ev.getY(0)).toDouble()
        return Math.toDegrees(atan2(dy, dx)).toFloat()
    }

    private fun normalizeAngle(deg: Float): Float {
        var r = deg % 360f
        if (r > 180f) r -= 360f
        if (r < -180f) r += 360f
        return r
    }

    private fun snapAngle(deg: Float): Float {
        val cardinal = floatArrayOf(-180f, -90f, 0f, 90f, 180f)
        for (c in cardinal) {
            if (abs(deg - c) <= 4f) return if (c == -180f) 180f else c
        }
        return deg
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun pxToDp(px: Int): Int = (px / resources.displayMetrics.density).roundToInt()
}
