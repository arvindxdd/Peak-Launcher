# Keep CanvasHome data models
-keep class com.canvashome.launcher.model.** { *; }
